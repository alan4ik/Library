#ifndef ADDITION_H
#define ADDITION_H

int add(int a, int b);

#endif
