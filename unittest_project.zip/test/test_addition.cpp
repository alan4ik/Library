#include "../src/addition.h"
#include <cassert>

int main() {
    // Проверка сложения положительных чисел
    int result = add(2, 3);
    assert(result == 6);

    // Проверка сложения отрицательных чисел
    result = add(-2, -3);
    assert(result == -5);

    // Добавьте дополнительные тесты здесь

    // Все тесты пройдены успешно
    return 0;
}
